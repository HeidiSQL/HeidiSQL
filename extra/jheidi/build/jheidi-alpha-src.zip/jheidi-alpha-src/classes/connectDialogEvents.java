import com.rendion.ajl.*;
import com.rendion.ajl.servlet.*;
import com.rendion.ajl.gui.*;
import javax.swing.*;
import java.util.*;

/* AjlScript generated script class */
public class connectDialogEvents extends AjlScript  {

public static void main( String args[] ) {
   connectDialogEvents script = new connectDialogEvents();
   script.run(args);
}

public Object run() {
/* Ajl Script Starts */
String who = arg("source");

log.debug("event received: " + who);
WindowContext context = argObj("windowContext");
Frame dialog = context.get("/");

Combo connProfiles = context.get("/connProfiles");
HashObject profiles = connProfiles.getProperty("profiles");


if ( "Delete".equals(who) )
{
if ( dialog.popupConfirm("Confirm Delete!", "Are you sure you want to delete this profile?") )
{
String profileToDelete = connProfiles.getText();
connProfiles.setProperty("lastProfile", null);
((DefaultComboBoxModel)connProfiles.getModel()).removeElement( profileToDelete );
profiles.remove(profiles.getObject(profileToDelete));
profiles.keySet().remove(profileToDelete);

}

}
else if ("Rename".equals(who) )
{
String newName = dialog.popupQuestion("Rename Connection", "Enter a new name for the connection profile:");
if ( newName != null )
{
DefaultComboBoxModel model = (DefaultComboBoxModel)connProfiles.getModel();
newName = newName.trim();

for (int i=0; i < model.getSize(); i++)
{
if (newName.equalsIgnoreCase((String)model.getElementAt(i)))
{
dialog.popupMessage("Cant Create!", "A profile with that name already exists!");
return null;
}
}

String profileToRename = connProfiles.getText();
HashObject profile = (HashObject)profiles.getObject(profileToRename);
profile.put("name", newName);
profiles.remove(profiles.getObject(profileToRename));
profiles.keySet().remove(profileToRename);
profiles.put(newName, profile);
connProfiles.setProperty("lastProfile", newName );
int pos = model.getIndexOf(profileToRename);
model.insertElementAt(newName, pos);
model.removeElementAt(pos+1);

}
}
else if ("New".equals(who) )
{
String newName = dialog.popupQuestion("New Connection", "Enter a name for the new connection profile:");
if ( newName != null )
{

DefaultComboBoxModel model = (DefaultComboBoxModel)connProfiles.getModel();
newName = newName.trim();

for (int i=0; i < model.getSize(); i++)
{
if (newName.equalsIgnoreCase((String)model.getElementAt(i)))
{
dialog.popupMessage("Cant Create!", "A profile with that name already exists!");
return null;
}
}

HashObject profile = ((HashObject)profiles.getObject("Default Local")).copy();
profile.put("name", newName);
profiles.put(newName, profile);
model.addElement(newName);
model.setSelectedItem(newName);

}

}
else if ("Save".equals(who) || "Save/Connect".equals(who) || "Connect".equals(who))
{
args().put("stateCmd", "flush");
args().put("profileKey", connProfiles.getText());
script("connectDialogState", args());

if ( who.startsWith("Save") )
{
StringBuilder buffer = new StringBuilder(1000);
for (HashObject h : (List<HashObject>) profiles)
{
buffer.append("name=").append(h.get("name")).append(":");
buffer.append("host=").append(h.get("host")).append(":");
buffer.append("user=").append(h.get("user")).append(":");
buffer.append("password=").append(h.get("password")).append(":");
buffer.append("port=").append(h.get("port")).append(":");
buffer.append("timeout=").append(h.get("timeout")).append(":");
buffer.append("compress=").append(h.get("compress")).append(":");
buffer.append("sort=").append(h.get("sort")).append(":");
buffer.append("dbs=").append(h.get("dbs")).append("\n");
}

FileUtil.fromString(".connectionProfiles", buffer.toString());
}

if ( who.endsWith("Connect"))
{
HashObject profile = (HashObject)profiles.getObject(connProfiles.getText());

args().put("profile", profile);
DB db = (DB)script("testConnect", args());
if (db != null)
{
dialog.dispose();
script("showMainWindow", args());
}
}

}
else if ("connProfiles".equals(who))
{
String lastProfileKey = connProfiles.getProperty("lastProfile");

if ( !connProfiles.getText().equals(lastProfileKey) )
{
if ( lastProfileKey != null  && profiles.getObject(lastProfileKey) != null )
{
args().put("stateCmd", "flush");
args().put("profileKey", lastProfileKey);
script("connectDialogState", args());
}

HashObject profile = (HashObject) profiles.getObject(connProfiles.getText());

((Field)context.get("/host")).setText(profile.get("host"));
((Field)context.get("/user")).setText(profile.get("user"));
((Password)context.get("/password")).setText(profile.get("password"));
((Field)context.get("/port")).setText(profile.get("port"));
((Field)context.get("/timeout")).setText(profile.get("timeout"));
((Field)context.get("/port")).setText(profile.get("port"));
((Field)context.get("/dbs")).setText(profile.get("dbs"));

boolean compress =  "true".equals(profile.get("compress"));
((CheckBox)context.get("/compress")).setSelected(compress);
boolean sort =  "true".equals(profile.get("sort"));
((CheckBox)context.get("/sort")).setSelected(sort);

boolean enabled = !"Default Local".equals(connProfiles.getText());
((Button)context.get("/Delete")).setEnabled(enabled);
((Button)context.get("/Rename")).setEnabled(enabled);

connProfiles.setProperty("lastProfile", connProfiles.getText());
}

}
else if ("Cancel".equals(who) )
{
dialog.disposeOrExit(0);
}


return null;
/* Ajl Script Ends */
}

}
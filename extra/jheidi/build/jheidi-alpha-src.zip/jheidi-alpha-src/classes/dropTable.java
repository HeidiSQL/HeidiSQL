import com.rendion.ajl.*;
import com.rendion.ajl.servlet.*;
import com.rendion.ajl.gui.*;

/* AjlScript generated script class */
public class dropTable extends AjlScript  {

public static void main( String args[] ) {
   dropTable script = new dropTable();
   script.run(args);
}

public Object run() {
/* Ajl Script Starts */

WindowContext context = argObj("windowContext");
String table = arg("tableToDrop");

DB db = context.get("db");

db.begin();
db.execute("use " + context.get("currentDB"));
db.execute("drop table " + table);
db.end();


return null;
/* Ajl Script Ends */
}

}
import com.rendion.ajl.*;
import com.rendion.ajl.servlet.*;
import com.rendion.ajl.gui.*;

/* AjlScript generated script class */
public class tableToolbarEvents extends AjlScript  {

public static void main( String args[] ) {
   tableToolbarEvents script = new tableToolbarEvents();
   script.run(args);
}

public Object run() {
/* Ajl Script Starts */

String who = arg("source");

WindowContext context = argObj("windowContext");
Table table = context.get("/mainTabs/Table/table");

log.debug("Event received: " + who);

if ( context.get("currentTable") == null )
{
return null;
}

if ("Delete Field".equals(who) )
{
if ( table.getSelectedRow() != -1 )
{
Frame frame = context.get("/");
String tableName = context.get("currentTable");
String fieldName =  (String)table.getValueAt(table.getSelectedRow(), 0);
if (frame.popupConfirm("Confirm Delete!", "Are you sure you want to drop field '" + tableName + "." + fieldName + "'?"))
{
args().put("fieldToDrop", fieldName);
script("dropField", args());

Panel tab = context.get("/mainTabs/Table");
String script = tab.getProperty("refreshScript");
thread(script, (HashObject)tab.getProperty("refreshArgs"), true);
}
}

}
else if ("New Field".equals(who))
{
args().put("fieldMode", "Add");
if ( script("fieldDialog", args()) != null )
{
//not sure maybe refresh the table tab
}

}
else if ("Edit Field".equals(who))
{
if ( table.getSelectedRow() != -1 )
{
String fieldName =  (String)table.getValueAt(table.getSelectedRow(), 0);
args().put("fieldMode", "Edit");
args().put("fieldToEdit", fieldName);
if ( script("fieldDialog", args()) != null )
{
//not sure maybe refresh the table tab
}
}
}
else if ("Manage Indexes".equals(who))
{
if ( script("indexDialog", args()) != null )
{
//not sure maybe refresh the table tab
}
}
else
{
((Frame)context.get("/")).popupMessage("Feature Unimplemented!");
}
return null;
/* Ajl Script Ends */
}

}
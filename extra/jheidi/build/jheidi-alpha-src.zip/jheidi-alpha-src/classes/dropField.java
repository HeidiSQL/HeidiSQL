import com.rendion.ajl.*;
import com.rendion.ajl.servlet.*;
import com.rendion.ajl.gui.*;

/* AjlScript generated script class */
public class dropField extends AjlScript  {

public static void main( String args[] ) {
   dropField script = new dropField();
   script.run(args);
}

public Object run() {
/* Ajl Script Starts */

WindowContext context = argObj("windowContext");
String field = arg("fieldToDrop");

DB db = context.get("db");

db.begin();
db.execute("use " + context.get("currentDB"));
db.execute("alter table " + context.get("currentTable") + " drop column " + field);
db.end();


return null;
/* Ajl Script Ends */
}

}
import com.rendion.ajl.*;
import com.rendion.ajl.servlet.*;
import com.rendion.ajl.gui.*;

/* AjlScript generated script class */
public class loadHostInfo extends AjlScript  {

public static void main( String args[] ) {
   loadHostInfo script = new loadHostInfo();
   script.run(args);
}

public Object run() {
/* Ajl Script Starts */

WindowContext context = argObj("windowContext");

DB db = context.get("db");

db.begin();
DB.Result version = db.query("select version()");
DB.Result vars = db.execute("show variables");
DB.Result processes = db.execute("show full processlist");
db.end();

Text  banner = context.get("/mainTabs/Host/toolbar/banner");
banner.setText("MySQL " + version.first().get(0));
Table varTable = context.get("/mainTabs/Host/tabs/Variables/table");
TableUtils.populate(varTable, vars);
Table processTable = context.get("/mainTabs/Host/tabs/Processes/table");
TableUtils.populate(processTable, processes);

//let the refresh button know what to do
Panel tab = context.get("/mainTabs/Host");
tab.setProperty("refreshScript", "loadHostInfo");
tab.setProperty("refreshArgs", args());

















return null;
/* Ajl Script Ends */
}

}
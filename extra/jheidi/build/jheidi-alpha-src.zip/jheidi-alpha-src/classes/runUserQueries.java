import com.rendion.ajl.*;
import com.rendion.ajl.servlet.*;
import com.rendion.ajl.gui.*;
import java.util.*;

/* AjlScript generated script class */
public class runUserQueries extends AjlScript  {

public static void main( String args[] ) {
   runUserQueries script = new runUserQueries();
   script.run(args);
}

public Object run() {
/* Ajl Script Starts */
HashObject userQueries = argObj("userQueries");
WindowContext context = argObj("windowContext");

DB.Result results = null;
DB db = context.get("db");
db.begin();
if (context.get("currentDB") != null)
{
db.execute("use " + context.get("currentDB"));
}
db.setLimit(1000);
for (String userQuery : (List<String>)userQueries)
{
try {
results = db.execute(userQuery);
}
catch (Exception e)
{
log.error("",e);
}
}
db.setLimit(-1);
db.end();

//if the last statement didnt have any results oh well!
Table t = context.get("/mainTabs/Query/results");
TableUtils.populate(t, results);


return null;
/* Ajl Script Ends */
}

}
import com.rendion.ajl.*;
import com.rendion.ajl.servlet.*;
import com.rendion.ajl.gui.*;
import javax.swing.table.*;

/* AjlScript generated script class */
public class resetTabs extends AjlScript  {

public static void main( String args[] ) {
   resetTabs script = new resetTabs();
   script.run(args);
}

public Object run() {
/* Ajl Script Starts */
WindowContext context = argObj("windowContext");
HashObject profile = context.get("profile");

Text banner = null;
Table table = null;

if ( "Host".equals(arg("selectedTab")) )
{
banner = context.get("/mainTabs/Database/toolbar/banner");
banner.setText("No database selected");
table = context.get("/mainTabs/Database/table");
table.clear();
banner = context.get("/mainTabs/Query/toolbar/banner");
banner.setText("SQL query on " + profile.get("user") + "@" + profile.get("host"));
}
else
{
banner = context.get("/mainTabs/Query/toolbar/banner");
banner.setText("SQL query on database: " + context.get("currentDB"));
}

banner = context.get("/mainTabs/Table/toolbar/banner");
banner.setText("No table selected");
table = context.get("/mainTabs/Table/table");
table.clear();
banner = context.get("/mainTabs/Data/toolbar/banner");
banner.setText("No table selected");
table = context.get("/mainTabs/Data/table");
table.clear();








return null;
/* Ajl Script Ends */
}

}
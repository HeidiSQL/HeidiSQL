import com.rendion.ajl.*;
import com.rendion.ajl.servlet.*;
import com.rendion.ajl.gui.*;

/* AjlScript generated script class */
public class loadDatabaseInfo extends AjlScript  {

public static void main( String args[] ) {
   loadDatabaseInfo script = new loadDatabaseInfo();
   script.run(args);
}

public Object run() {
/* Ajl Script Starts */

WindowContext context = argObj("windowContext");

DB db = context.get("db");
DB.Result databases = db.execute("show table status from " + arg("dbName"));

Text banner = context.get("/mainTabs/Database/toolbar/banner");
banner.setText("Database " + arg("dbName") + ": " + databases.size() + " table(s)");

banner = context.get("/mainTabs/Query/toolbar/banner");
banner.setText("SQL query on database: " + arg("dbName"));

TableUtils.populate((Table)context.get("/mainTabs/Database/table"), databases);

//let the refresh button know what to do
Panel tab = context.get("/mainTabs/Database");
tab.setProperty("refreshScript", "loadDatabaseInfo");
tab.setProperty("refreshArgs", args());
















return null;
/* Ajl Script Ends */
}

}
import com.rendion.ajl.*;
import com.rendion.ajl.servlet.*;
import com.rendion.ajl.gui.*;

/* AjlScript generated script class */
public class initTree extends AjlScript  {

public static void main( String args[] ) {
   initTree script = new initTree();
   script.run(args);
}

public Object run() {
/* Ajl Script Starts */

WindowContext context = argObj("windowContext");
HashObject profile = context.get("profile");
Tree tree = context.get("/schemaTree");
NodeInfo root = (NodeInfo)tree.getModel().getRoot();

if ( root.getText().equals("A Tree") )
{
//we are new and not in a refresh
tree.setCellRenderer(new IconicCellRenderer("images/db.gif", "images/instance.gif", "images/table.gif"));
root.setText(profile.get("user") + "@" + profile.get("host"));
root.setIcon("instance");
}
root.removeAllChildren();

DB db = context.get("db");
db.begin();
DB.Result databases = db.execute("show databases");
log.debug("database count:" + databases.size());
HashObject dbNodes = TreeUtils.populateList(root, databases, 0, "db");

for ( HashObject _dbs : databases )
{
String dbName = (String) _dbs.get(0);
DB.Result tables = db.execute("show tables from " + dbName);
log.debug("adding tables to node (" + dbName + ") " + dbNodes.getObject(dbName));
TreeUtils.populateList((NodeInfo)dbNodes.getObject(dbName), tables, 0, "table");
}

db.end();

tree.updateUI();















return null;
/* Ajl Script Ends */
}

}
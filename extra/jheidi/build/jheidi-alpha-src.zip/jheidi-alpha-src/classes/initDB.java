import com.rendion.ajl.*;
import com.rendion.ajl.servlet.*;
import com.rendion.ajl.gui.*;
import com.mysql.jdbc.jdbc2.optional.*;
import javax.sql.DataSource;
import com.rendion.editor.*;

/* AjlScript generated script class */
public class initDB extends AjlScript  {

public static void main( String args[] ) {
   initDB script = new initDB();
   script.run(args);
}

public Object run() {
/* Ajl Script Starts */
DB db = null;

WindowContext context = argObj("windowContext");
HashObject profile = context.get("profile");
AjlEditor editor = context.get("/consoleTabs/SQL Log/outputWindow");

try
{
MysqlDataSource ds = new MysqlDataSource();
String url = "jdbc:mysql://" + profile.get("host") + ":" + profile.get("port") + "/";

ds.setUrl(url);
ds.setUser(profile.get("user"));
ds.setPassword(profile.get("password"));

db = new SQLLoggingDB((DataSource)ds, editor);

} catch (Exception e) {
throw new RuntimeException(e);
}

context.put("db", db);

return null;
/* Ajl Script Ends */
}

}
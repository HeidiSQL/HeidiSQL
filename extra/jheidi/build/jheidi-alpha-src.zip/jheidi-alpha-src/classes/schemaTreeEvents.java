import com.rendion.ajl.*;
import com.rendion.ajl.servlet.*;
import com.rendion.ajl.gui.*;

/* AjlScript generated script class */
public class schemaTreeEvents extends AjlScript  {

public static void main( String args[] ) {
   schemaTreeEvents script = new schemaTreeEvents();
   script.run(args);
}

public Object run() {
/* Ajl Script Starts */

NodeInfo node = argObj("node");
WindowContext context = argObj("windowContext");

Tabs tabs = context.get("/mainTabs");
String selectedTab = tabs.selected();
String nodeType = node.getType();

log.debug("node type = " + nodeType);
log.debug("selected tab = " + selectedTab);

if ( nodeType == null )
{
tabs.select("Host");
args().put("selectedTab", "Host");
thread("resetTabs", args(), true);
}
else if ( "db".equals(nodeType) )
{
String dbName = node.getText();
Panel tab = tabs.select("Database");
if ( !dbName.equals(context.get("currentDB")) )
{
context.put("currentDB", dbName);
context.remove("currentTable");
args().put("selectedTab", "Database");
thread("resetTabs", args(), true);
args().put("dbName", dbName);
thread("loadDatabaseInfo", args(), true);
}
}
else if ( "table".equals(nodeType) )
{
String dbName = node.getParent().getText();
String tableName = node.getText();

Panel tab = tabs.get("Table");
if ("Host".equals(selectedTab) || "Database".equals(selectedTab))
{
tabs.select("Table");
}

if (!dbName.equals(context.get("currentDB")))
{
context.put("currentDB", dbName);
args().put("dbName", dbName);
thread("loadDatabaseInfo", args(), true);
}

if ( !tableName.equals(context.get("currentTable")) || !dbName.equals(context.get("currentDB")) )
{
context.put("currentTable", node.getText());
args().put("dbName", dbName);
args().put("tableName", tableName);
thread("loadTableInfo", args(), true);
thread("loadTableData", args(), true);
}
}



















return null;
/* Ajl Script Ends */
}

}